import { useEffect, useMemo, useState } from "react";
import { AdminSection, EmptyState } from "./AdminUI";
import { useCrud } from "./crud";
import { supabase } from "@/lib/supabase";
import type { Report, ReportStatus } from "@/lib/supabase";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Flag, Eye, Trash2, User, Calendar, ChevronLeft, ChevronRight, X } from "lucide-react";
import { cn } from "@/lib/utils";

const FILTERS: { value: ReportStatus | "all"; label: string }[] = [
  { value: "all", label: "All" },
  { value: "pending", label: "Pending" },
  { value: "in_review", label: "In review" },
  { value: "resolved", label: "Resolved" },
  { value: "dismissed", label: "Dismissed" },
];

function statusBadge(s: ReportStatus) {
  const map: Record<ReportStatus, string> = {
    pending: "bg-amber-500/20 text-amber-300",
    in_review: "bg-blue-500/20 text-blue-300",
    resolved: "bg-emerald-500/20 text-emerald-300",
    dismissed: "bg-slate-500/20 text-slate-300",
  };
  return <Badge className={cn("capitalize", map[s])}>{s.replace("_", " ")}</Badge>;
}

function screenshotList(raw: string | string[] | null | undefined): string[] {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw;
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((u) => typeof u === "string") : [raw];
  } catch {
    return [raw];
  }
}

export function ReportsPanel() {
  const { rows, loading, update, remove } = useCrud<Report>("reports");
  const [filter, setFilter] = useState<ReportStatus | "all">("all");
  const [tournamentFilter, setTournamentFilter] = useState<string>("all");
  const [viewing, setViewing] = useState<Report | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const [tournaments, setTournaments] = useState<{ id: string; name: string }[]>([]);
  const [reporterNames, setReporterNames] = useState<Map<string, string>>(new Map());

  useEffect(() => {
    void (async () => {
      const { data } = await supabase.from("tournaments").select("id, name").order("name");
      setTournaments(data ?? []);
    })();
  }, []);

  useEffect(() => {
    const ids = [...new Set(rows.map((r) => r.reporter_id).filter(Boolean))] as string[];
    if (ids.length === 0) return;
    void (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, username")
        .in("id", ids);
      const map = new Map<string, string>();
      for (const p of data ?? []) {
        map.set(p.id, p.full_name || p.username || "Unknown user");
      }
      setReporterNames(map);
    })();
  }, [rows]);

  const tournamentName = (id: string | null | undefined) =>
    tournaments.find((t) => t.id === id)?.name ?? "Unknown tournament";

  const list = useMemo(() => {
    return rows.filter((r) => {
      if (filter !== "all" && r.status !== filter) return false;
      if (tournamentFilter !== "all" && r.tournament_id !== tournamentFilter) return false;
      return true;
    });
  }, [rows, filter, tournamentFilter]);

  const pendingCount = rows.filter((r) => r.status === "pending").length;

  const viewingScreenshots = screenshotList(viewing?.screenshot_url);

  const nextPhoto = () =>
    setLightboxIndex((i) => (i === null ? null : (i + 1) % viewingScreenshots.length));
  const prevPhoto = () =>
    setLightboxIndex((i) =>
      i === null ? null : (i - 1 + viewingScreenshots.length) % viewingScreenshots.length,
    );

  let touchStartX = 0;
  const onTouchStart = (e: React.TouchEvent) => {
    touchStartX = e.touches[0].clientX;
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    const delta = e.changedTouches[0].clientX - touchStartX;
    if (Math.abs(delta) < 40) return;
    if (delta < 0) nextPhoto();
    else prevPhoto();
  };

  return (
    <AdminSection
      title="Reports"
      description={`${pendingCount} report${pendingCount === 1 ? "" : "s"} waiting for review.`}
      action={
        <div className="flex flex-wrap items-center gap-2">
          <Select value={tournamentFilter} onValueChange={setTournamentFilter}>
            <SelectTrigger className="w-44">
              <SelectValue placeholder="All tournaments" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All tournaments</SelectItem>
              {tournaments.map((t) => (
                <SelectItem key={t.id} value={t.id}>
                  {t.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex flex-wrap gap-1.5">
            {FILTERS.map((f) => (
              <Button
                key={f.value}
                size="sm"
                variant={filter === f.value ? "default" : "outline"}
                onClick={() => setFilter(f.value)}
              >
                {f.label}
              </Button>
            ))}
          </div>
        </div>
      }
    >
      {loading ? (
        <div className="text-muted-foreground">Loading reports…</div>
      ) : list.length === 0 ? (
        <EmptyState message="No reports in this view." />
      ) : (
        <div className="space-y-2">
          {list.map((r) => {
            const shots = screenshotList(r.screenshot_url);
            return (
              <div
                key={r.id}
                className="flex flex-wrap items-center gap-3 rounded-xl border border-border/60 p-4"
              >
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-rose-500/15">
                  <Flag className="h-4 w-4 text-rose-400" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">{r.reason}</span>
                    {statusBadge(r.status)}
                    <Badge variant="outline" className="capitalize">{r.type}</Badge>
                    {shots.length > 0 && (
                      <Badge variant="outline">
                        {shots.length} photo{shots.length > 1 ? "s" : ""}
                      </Badge>
                    )}
                  </div>
                  <p className="mt-0.5 truncate text-xs text-muted-foreground">
                    {tournamentName(r.tournament_id)} · Reported by {(r.reporter_id ? reporterNames.get(r.reporter_id) : null) ?? "…"}
                    {r.player_name ? ` · Player: ${r.player_name}` : ""} · {new Date(r.created_at).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button size="sm" variant="outline" onClick={() => setViewing(r)}>
                    <Eye className="mr-1.5 h-3.5 w-3.5" /> View
                  </Button>
                  <Select
                    value={r.status}
                    onValueChange={(v) => update(r.id, { status: v as ReportStatus })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in_review">In review</SelectItem>
                      <SelectItem value="resolved">Resolve</SelectItem>
                      <SelectItem value="dismissed">Dismiss</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="text-destructive"
                    onClick={() => {
                      if (confirm("Delete this report?")) remove(r.id);
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 1. MAIN REPORT DETAILS DIALOG */}
      <Dialog 
        open={!!viewing && lightboxIndex === null} 
        onOpenChange={(open) => { if (!open) setViewing(null); }}
      >
        <DialogContent className="glass max-w-lg">
          <DialogHeader>
            <DialogTitle>Report details</DialogTitle>
          </DialogHeader>
          {viewing && (
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                {statusBadge(viewing.status)}
                <Badge variant="outline" className="capitalize">{viewing.type}</Badge>
              </div>
              <p className="text-lg font-semibold">{viewing.reason}</p>
              {viewing.description && (
                <p className="whitespace-pre-line text-muted-foreground">{viewing.description}</p>
              )}
              <div className="space-y-1.5 rounded-xl border border-border/60 p-3 text-xs text-muted-foreground">
                <p className="flex items-center gap-2">
                  <Flag className="h-3.5 w-3.5" /> Tournament: {tournamentName(viewing.tournament_id)}
                </p>
                <p className="flex items-center gap-2">
                  <User className="h-3.5 w-3.5" /> Reported by: {(viewing.reporter_id ? reporterNames.get(viewing.reporter_id) : null) ?? "Unknown user"}
                </p>
                {viewing.player_name && (
                  <p className="flex items-center gap-2">
                    <User className="h-3.5 w-3.5" /> Reported player: {viewing.player_name}
                  </p>
                )}
                <p className="flex items-center gap-2">
                  <Calendar className="h-3.5 w-3.5" /> {new Date(viewing.created_at).toLocaleString()}
                </p>
              </div>

              {/* SCREENSHOT PREVIEWS */}
              {viewingScreenshots.length > 0 && (
                <div>
                  <p className="mb-1.5 text-xs font-medium text-muted-foreground">Screenshots</p>
                  <div className="flex flex-wrap gap-2">
                    {viewingScreenshots.map((url, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setLightboxIndex(i)}
                        className="group relative h-20 w-20 overflow-hidden rounded-lg border border-border/60 hover:border-primary focus:outline-none"
                      >
                        <img src={url} alt={`Screenshot ${i + 1}`} className="h-full w-full object-cover group-hover:scale-105 transition-transform" />
                        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <Eye className="h-5 w-5 text-white" />
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => { update(viewing.id, { status: "dismissed" }); setViewing(null); }}>
                  Dismiss
                </Button>
                <Button className="bg-gradient-brand" onClick={() => { update(viewing.id, { status: "resolved" }); setViewing(null); }}>
                  Mark resolved
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* 2. LIGHTBOX DIALOG (MODAL DISCONNECT PATTERN) */}
      <Dialog 
        open={lightboxIndex !== null} 
        onOpenChange={(open) => { if (!open) setLightboxIndex(null); }}
      >
        <DialogContent className="max-w-4xl p-0 border-none bg-transparent shadow-none [&>button]:hidden">
          <div
            className="relative flex h-[85vh] w-full items-center justify-center bg-black/90 rounded-2xl overflow-hidden p-4"
            onTouchStart={onTouchStart}
            onTouchEnd={onTouchEnd}
          >
            {/* Close Lightbox */}
            <button
              type="button"
              onClick={() => setLightboxIndex(null)}
              className="absolute right-4 top-4 z-50 grid h-10 w-10 place-items-center rounded-full bg-white/20 text-white hover:bg-white/30 transition"
            >
              <X className="h-6 w-6" />
            </button>

            {/* Prev Image */}
            {viewingScreenshots.length > 1 && (
              <button
                type="button"
                onClick={prevPhoto}
                className="absolute left-4 z-50 grid h-12 w-12 place-items-center rounded-full bg-white/20 text-white hover:bg-white/30 transition"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
            )}

            {/* Image Element */}
            {lightboxIndex !== null && viewingScreenshots[lightboxIndex] && (
              <img
                src={viewingScreenshots[lightboxIndex]}
                alt={`Screenshot ${lightboxIndex + 1}`}
                className="max-h-full max-w-full rounded-lg object-contain select-none"
              />
            )}

            {/* Next Image */}
            {viewingScreenshots.length > 1 && (
              <button
                type="button"
                onClick={nextPhoto}
                className="absolute right-4 z-50 grid h-12 w-12 place-items-center rounded-full bg-white/20 text-white hover:bg-white/30 transition"
              >
                <ChevronRight className="h-6 w-6" />
              </button>
            )}

            {/* Page Count */}
            {viewingScreenshots.length > 1 && (
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-black/60 px-4 py-1 text-xs text-white border border-white/10">
                {(lightboxIndex ?? 0) + 1} / {viewingScreenshots.length}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </AdminSection>
  );
}

export default ReportsPanel;
      
